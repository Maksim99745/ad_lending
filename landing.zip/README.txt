Quick start after unzip:

1) Open index.html in browser

Hosting:
- Upload all files from this folder preserving structure.
- Start page: index.html
- Required folder: moneystyle.net/usefull_landing_0602/
